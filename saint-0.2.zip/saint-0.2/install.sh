#!/usr/bin/env bash
# =============================================================================
#  SAINT 0.2  —  Security Analysis, Investigation & Network Triage
#  A defender's layer on top of a fresh Arch Linux install.
#
#  Run as your normal user (NOT root) on a freshly installed Arch system:
#      bash install.sh
#
#  What it does:
#    1. base update + enable multilib
#    2. NVIDIA open drivers (RTX 50-series / Blackwell) + early KMS
#    3. Hyprland desktop (Wayland) + full session
#    4. blue-team / DFIR toolkit (Wazuh, Sysmon, Volatility, YARA, hashcat, ...)
#    5. clones your cheat-sheets + home-soc-lab into ~/saint
#    6. installs the SAINT Plymouth boot splash (if ./plymouth/saint is present)
#
#  Nothing here is irreversible on a fresh install, but read it before running.
# =============================================================================
set -uo pipefail

# ---- pretty output ----------------------------------------------------------
c1='\033[38;5;203m'; c2='\033[38;5;215m'; c3='\033[38;5;222m'; dim='\033[2m'; rst='\033[0m'
say(){ printf "${c2}::${rst} %s\n" "$*"; }
ok(){  printf "${c3}[ ok ]${rst} %s\n" "$*"; }
warn(){ printf "${c1}[warn]${rst} %s\n" "$*"; }
FAILED=()
note_fail(){ FAILED+=("$1"); warn "could not install: $1"; }

SAINT_DIR="$HOME/saint"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

banner(){
  printf "${c1}"
  cat <<'EOF'
   ___  ___   _   _  _ _____
  / __|/ _ \ | | | \| |_   _|   SAINT 0.2
  \__ \ (_) || | | .` | | |     a defender's Arch
  |___/\___/ |_| |_|\_| |_|     Kali destroys. SAINT protects.
EOF
  printf "${rst}\n"
}

# ---- preflight --------------------------------------------------------------
preflight(){
  [[ $EUID -eq 0 ]] && { warn "run as a normal user, not root (it uses sudo)."; exit 1; }
  command -v pacman >/dev/null || { warn "this is not Arch (no pacman)."; exit 1; }
  command -v sudo   >/dev/null || { warn "sudo is required."; exit 1; }
  ping -c1 -W3 archlinux.org >/dev/null 2>&1 || warn "no internet? downloads may fail."
  say "running as $USER on $(. /etc/os-release; echo "$PRETTY_NAME")"
  read -rp "$(printf "${c2}::${rst} proceed with SAINT 0.2 install? [y/N] ")" a
  [[ ${a,,} == y* ]] || { echo "aborted."; exit 0; }
}

# ---- helpers ----------------------------------------------------------------
pac(){ sudo pacman -S --needed --noconfirm "$@"; }

enable_multilib(){
  if ! grep -q '^\[multilib\]' /etc/pacman.conf; then
    say "enabling [multilib] repo"
    sudo sed -i '/^#\[multilib\]/,+1 s/^#//' /etc/pacman.conf
  fi
  sudo pacman -Sy --noconfirm
}

install_yay(){
  command -v yay >/dev/null && { ok "yay present"; return; }
  say "building yay (AUR helper)"
  pac git base-devel
  local t; t="$(mktemp -d)"
  git clone -q https://aur.archlinux.org/yay-bin.git "$t/yay-bin" \
    && ( cd "$t/yay-bin" && makepkg -si --noconfirm ) \
    || note_fail "yay (AUR helper) — AUR packages will be skipped"
  rm -rf "$t"
}

# install AUR packages one-by-one so one failure doesn't kill the rest
aur(){
  command -v yay >/dev/null || { for p in "$@"; do note_fail "$p (no yay)"; done; return; }
  local p
  for p in "$@"; do
    say "AUR: $p"
    yay -S --needed --noconfirm "$p" || note_fail "$p (AUR)"
  done
}

pipx_install(){
  command -v pipx >/dev/null || pac python-pipx
  local p
  for p in "$@"; do
    say "pipx: $p"
    pipx install --quiet "$p" 2>/dev/null || pipx upgrade "$p" 2>/dev/null || note_fail "$p (pipx)"
  done
}

# =============================================================================
#  1. base
# =============================================================================
step_base(){
  say "updating system + base tools"
  sudo pacman -Syu --noconfirm
  pac base-devel git curl wget unzip vim neovim jq ripgrep fd bat eza htop \
      openssh man-db reflector python python-pip
}

# =============================================================================
#  2. NVIDIA  (RTX 5050 / Blackwell needs the OPEN modules + recent driver)
# =============================================================================
step_nvidia(){
  say "installing NVIDIA open drivers + 32-bit libs"
  pac linux-headers nvidia-open-dkms nvidia-utils lib32-nvidia-utils \
      egl-wayland libva-nvidia-driver nvidia-settings || note_fail "nvidia packages"

  # early KMS: load the modules in the initramfs
  if ! grep -q 'nvidia_drm' /etc/mkinitcpio.conf; then
    say "adding nvidia modules to mkinitcpio"
    sudo sed -i 's/^MODULES=(\(.*\))/MODULES=(\1 nvidia nvidia_modeset nvidia_uvm nvidia_drm)/' /etc/mkinitcpio.conf
    sudo sed -i 's/  */ /g; s/MODULES=( /MODULES=(/' /etc/mkinitcpio.conf
  fi
  # modeset + fbdev so Wayland + the splash work on Blackwell
  echo 'options nvidia_drm modeset=1 fbdev=1' | sudo tee /etc/modprobe.d/nvidia.conf >/dev/null
  sudo mkinitcpio -P || warn "mkinitcpio reported issues — check before reboot"
  ok "NVIDIA set up (open modules, modeset on). Add 'nvidia_drm.modeset=1' to kernel cmdline too."
}

# =============================================================================
#  3. Hyprland desktop (Wayland)
# =============================================================================
step_hyprland(){
  say "installing Hyprland + Wayland session"
  pac hyprland xdg-desktop-portal-hyprland hyprpaper hyprlock hypridle \
      waybar wofi kitty mako thunar grim slurp wl-clipboard \
      polkit-kde-agent qt5-wayland qt6-wayland \
      pipewire pipewire-pulse pipewire-alsa wireplumber \
      networkmanager network-manager-applet brightnessctl pavucontrol playerctl \
      ttf-jetbrains-mono-nerd ttf-font-awesome noto-fonts noto-fonts-emoji \
      fastfetch fish \
      greetd greetd-tuigreet || note_fail "some desktop packages"

  # wlogout is AUR-only; keeping it out of the pacman line above avoids
  # failing the whole transaction when one target isn't in the repos.
  say "AUR: eww + wlogout (dashboard widgets / power menu)"
  aur eww wlogout
  sudo systemctl enable NetworkManager.service

  # greetd -> launches Hyprland after login
  sudo mkdir -p /etc/greetd
  sudo tee /etc/greetd/config.toml >/dev/null <<EOF
[terminal]
vt = 1
[default_session]
command = "tuigreet --time --remember --cmd Hyprland"
user = "greeter"
EOF
  sudo systemctl enable greetd.service

  deploy_theme
  ok "Hyprland installed"
}

deploy_theme(){
  local src="$HERE/saint-theme"
  if [[ ! -d "$src" ]]; then
    warn "saint-theme/ not found next to script — writing minimal config instead"
    write_hypr_config; return
  fi
  say "deploying SAINT theme (hypr, waybar, wofi, kitty, mako + wallpaper)"
  mkdir -p "$HOME/.config"
  local d
  for d in hypr waybar wofi kitty mako fastfetch eww; do
    [[ -d "$src/$d" ]] || continue
    [[ -d "$HOME/.config/$d" ]] && cp -a "$HOME/.config/$d" "$HOME/.config/$d.bak-$(date +%s)" 2>/dev/null || true
    mkdir -p "$HOME/.config/$d"
    cp -af "$src/$d/." "$HOME/.config/$d/"
  done
  # make the wallpaper launcher executable + expand ~ to an absolute path
  # (hyprpaper does not expand ~, and it needs the real $HOME)
  chmod +x "$HOME/.config/hypr/wall.sh" 2>/dev/null || true
  [[ -f "$HOME/.config/hypr/hyprpaper.conf" ]] && \
    sed -i "s|~/|$HOME/|g" "$HOME/.config/hypr/hyprpaper.conf" 2>/dev/null || true
  ok "SAINT theme deployed (any old configs backed up to ~/.config/<app>.bak-*)"
}

write_hypr_config(){
  local cfg="$HOME/.config/hypr"
  mkdir -p "$cfg"
  [[ -f "$cfg/hyprland.conf" ]] && cp "$cfg/hyprland.conf" "$cfg/hyprland.conf.bak"
  cat > "$cfg/hyprland.conf" <<'EOF'
# --- SAINT minimal Hyprland config (0.1) ---
monitor=,preferred,auto,1

# NVIDIA-friendly env
env = LIBVA_DRIVER_NAME,nvidia
env = __GLX_VENDOR_LIBRARY_NAME,nvidia
env = NVD_BACKEND,direct
env = XDG_SESSION_TYPE,wayland
env = MOZ_ENABLE_WAYLAND,1

exec-once = waybar & hyprpaper & mako & nm-applet --indicator
exec-once = /usr/lib/polkit-kde-authentication-agent-1

$mod = SUPER
general {
  gaps_in = 5
  gaps_out = 12
  border_size = 2
  col.active_border = rgba(ff2a16ee) rgba(ffc531ee) 45deg
  col.inactive_border = rgba(222222aa)
}
decoration { rounding = 6 }
bind = $mod, Q, exec, kitty
bind = $mod, C, killactive,
bind = $mod, E, exec, thunar
bind = $mod, R, exec, wofi --show drun
bind = $mod, M, exit,
bind = $mod, V, togglefloating,
bind = $mod, F, fullscreen,
bind = $mod, 1, workspace, 1
bind = $mod, 2, workspace, 2
bind = $mod, 3, workspace, 3
bind = $mod SHIFT, 1, movetoworkspace, 1
bind = $mod SHIFT, 2, movetoworkspace, 2
bind = $mod, left, movefocus, l
bind = $mod, right, movefocus, r
bind = $mod, up, movefocus, u
bind = $mod, down, movefocus, d
EOF
  # solid dark wallpaper for hyprpaper (replace with SAINT art later)
  cat > "$cfg/hyprpaper.conf" <<'EOF'
preload =
# drop a wallpaper at ~/.config/hypr/wall.png and uncomment:
# wallpaper = ,~/.config/hypr/wall.png
EOF
  ok "wrote starter Hyprland config (backup: hyprland.conf.bak if it existed)"
}

# =============================================================================
#  4. blue-team / DFIR toolkit
# =============================================================================
step_tools(){
  say "installing SOC / DFIR toolkit (official repos)"
  # note: 'ncat' ships inside the 'nmap' package (not a separate target);
  # 'suricata' moved to the AUR, so both are handled below, not here.
  pac wireshark-qt tcpdump nmap yara \
      hashcat hashcat-utils hcxtools john \
      python-pipx git-delta || note_fail "some repo tools"

  say "AUR tools (build from source — may take a while)"
  aur sysmonforlinux-bin wazuh-agent suricata
  # velociraptor + cyberchef aren't reliable AUR targets — grab their
  # binary releases manually (see the summary at the end).

  say "python-based analysis tools (pipx)"
  pipx_install volatility3 oletools

  # let your user capture packets without sudo
  sudo usermod -aG wireshark "$USER" 2>/dev/null || true
  ok "toolkit installed"
}

# =============================================================================
#  5. clone your portfolio repos into ~/saint
# =============================================================================
step_repos(){
  say "cloning your repos into $SAINT_DIR"
  mkdir -p "$SAINT_DIR"
  clone(){ [[ -d "$SAINT_DIR/$2" ]] && { ok "$2 present"; return; }
           git clone -q "https://github.com/XanDuri/$1.git" "$SAINT_DIR/$2" \
           || note_fail "clone $1"; }
  clone cybersec-cheat-sheets cheat-sheets
  clone home-soc-lab          home-soc-lab
  ok "repos in $SAINT_DIR"
}

# =============================================================================
#  6. Plymouth boot splash (optional: needs ./plymouth/saint next to this script)
# =============================================================================
step_plymouth(){
  local src=""
  [[ -d "$HERE/plymouth/saint" ]] && src="$HERE/plymouth/saint"
  [[ -d "$HERE/saint/saint.script" ]] && src="$HERE/saint"   # if unzipped flat
  [[ -z "$src" && -d "$HERE/saint" && -f "$HERE/saint/saint.plymouth" ]] && src="$HERE/saint"
  if [[ -z "$src" ]]; then
    warn "SAINT Plymouth theme not found next to this script — skipping."
    warn "  (unzip saint-plymouth.zip here so ./saint/saint.plymouth exists, then re-run with: bash install.sh --plymouth-only)"
    return
  fi
  say "installing SAINT Plymouth splash"
  pac plymouth || { note_fail "plymouth"; return; }
  sudo cp -r "$src" /usr/share/plymouth/themes/saint

  # add plymouth hook after udev/systemd, before encrypt
  if ! grep -q 'plymouth' /etc/mkinitcpio.conf; then
    sudo sed -i 's/\(HOOKS=.*\budev\b\)/\1 plymouth/' /etc/mkinitcpio.conf
    sudo sed -i 's/\(HOOKS=.*\bsystemd\b\)/\1 plymouth/' /etc/mkinitcpio.conf
  fi
  sudo plymouth-set-default-theme -R saint || note_fail "set plymouth theme"
  ok "SAINT splash installed. Add 'quiet splash' to kernel cmdline to see it."
}

# ---- run --------------------------------------------------------------------
main(){
  banner
  if [[ "${1:-}" == "--plymouth-only" ]]; then preflight; step_plymouth; summary; exit 0; fi
  preflight
  enable_multilib
  install_yay
  step_base
  step_nvidia
  step_hyprland
  step_tools
  step_repos
  step_plymouth
  summary
}

summary(){
  echo
  printf "${c1}=== SAINT 0.2 — done ===${rst}\n"
  if ((${#FAILED[@]})); then
    warn "${#FAILED[@]} item(s) need a second look:"
    printf '   - %s\n' "${FAILED[@]}"
  else
    ok "everything installed cleanly."
  fi
  cat <<EOF

${dim}Next steps (manual, one-time):${rst}
  1. Kernel cmdline — add:  nvidia_drm.modeset=1 quiet splash
       systemd-boot:  /boot/loader/entries/*.conf  (the 'options' line)
       GRUB:          GRUB_CMDLINE_LINUX_DEFAULT in /etc/default/grub, then
                      sudo grub-mkconfig -o /boot/grub/grub.cfg
  2. Point the Wazuh agent at your lab server:
       sudo nano /var/ossec/etc/ossec.conf   # <address>192.168.56.11</address>
       sudo systemctl enable --now wazuh-agent
  3. Reboot. tuigreet -> log in -> Hyprland.
       SUPER+Q terminal · SUPER+R app launcher · SUPER+C close
  4. Optional tools without a clean AUR package — grab binary releases:
       Velociraptor: https://github.com/Velocidex/velociraptor/releases
       CyberChef:    https://github.com/gchq/CyberChef/releases (open in a browser)

Notes:
  - Hyprland 0.57+ uses a Lua config (~/.config/hypr/hyprland.lua). The shipped
    theme is Lua; the old hyprland.conf format is ignored by this version.
  - A "started without start-hyprland" notice on login is cosmetic (tuigreet
    launches Hyprland directly) — the session works normally.

Your tools & notes live in: $SAINT_DIR
EOF
}

main "$@"
