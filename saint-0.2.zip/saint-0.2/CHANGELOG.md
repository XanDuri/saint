# Changelog

## 0.2 — 2026-11-27

Fixes from the first live install on the Lenovo LOQ.

### Install script
- **Desktop packages:** moved `wlogout` out of the pacman line (it's AUR-only —
  one missing repo target was failing the whole transaction) into the AUR step.
- **Toolkit:** removed `ncat` (it ships inside `nmap`, not a separate package)
  and `suricata` (moved to the AUR) from the pacman line; both broke the
  transaction. `suricata` is now attempted via AUR (best-effort).
- Dropped `velociraptor-bin` / `cyberchef` from the AUR step (not reliable AUR
  targets) — the summary now points to their binary releases instead.
- `deploy_theme` now makes `wall.sh` executable and expands `~` to `$HOME` in
  `hyprpaper.conf` (hyprpaper does not expand `~`).

### Desktop theme
- **Hyprland config ported to Lua** (`hyprland.lua`) for Hyprland 0.57+, which
  dropped the legacy `.conf` format. Crimson theme, keybinds, NVIDIA env and
  autostart preserved; windows now open floating; shadows off for a cleaner look.
- **Wallpaper race fixed:** new `wall.sh` waits for the monitor, then sets the
  wallpaper on whatever output Hyprland reports (works on any machine).
- **Waybar:** added a Start-menu button (Arch icon → app launcher) and made the
  bar one continuous full-width strip.
- **eww dashboard:** fixed the `metric` widget calls to use named attributes
  (`:l :v :pct`) — the dashboard now renders.
- **wofi:** launcher now opens under the Start button (top-left), not centre.
- **hypridle:** added `hypridle.conf` — auto-lock after 5 min, screen off after 6.

## 0.1

Initial build: Arch + LUKS, NVIDIA open, Hyprland, DFIR toolkit, Plymouth splash.
