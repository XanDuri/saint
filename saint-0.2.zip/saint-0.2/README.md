# SAINT 0.2 — a defender's Arch

**S**ecurity **A**nalysis, **I**nvestigation & **N**etwork **T**riage — a blue-team
layer on top of a fresh Arch Linux install. *Kali destroys. SAINT protects.*

## Install

Unzip, then from inside the folder, as your **normal user** (not root) on a
freshly installed Arch system:

    cd saint-0.2
    bash install.sh

It installs the NVIDIA open driver (RTX 50-series), a themed Hyprland desktop,
the blue-team / DFIR toolkit, clones your repos into `~/saint`, and installs the
SAINT boot splash. AUR failures don't stop the run — they're listed at the end.

## Contents

    install.sh        the installer (idempotent-ish)
    saint-theme/      hypr · waybar · wofi · kitty · mako · eww · fastfetch
    plymouth/saint/   the SAINT boot splash (auto-installed)

## Desktop

Hyprland (Wayland) + Waybar (crimson taskbar with a Start-menu button) + eww
dashboard (System / Music / Tasks cards) + crimson theme + red-leaves wallpaper.
Edit your task list in `~/.config/eww/tasks.txt`.

**Keybinds:** `SUPER+Q` terminal · `SUPER+R` launcher · `SUPER+C` close ·
`SUPER+L` lock · `SUPER+SHIFT+S` region screenshot · `SUPER+V` toggle floating.

## After install (manual, one-time)

1. Kernel cmdline — add `nvidia_drm.modeset=1 quiet splash` to the `options`
   line in `/boot/loader/entries/*.conf` (systemd-boot).
2. Point the Wazuh agent at your lab: `/var/ossec/etc/ossec.conf`.
3. Reboot.

> Hyprland 0.57+ uses a **Lua** config (`~/.config/hypr/hyprland.lua`). The old
> `hyprland.conf` format is ignored by this version — SAINT ships the Lua one.
