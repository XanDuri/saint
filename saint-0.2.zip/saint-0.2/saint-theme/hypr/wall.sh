#!/usr/bin/env bash
# SAINT wallpaper launcher — fixes the hyprpaper startup race by waiting for
# the monitor to be ready, then applying the wallpaper to whatever output
# Hyprland reports (so it works on any machine, not just eDP-2).
sleep 1.5
pidof hyprpaper >/dev/null || hyprpaper &
sleep 1
WP="$HOME/.config/hypr/wall.png"
[ -f "$WP" ] || exit 0
MON="$(hyprctl monitors -j 2>/dev/null | jq -r '.[0].name' 2>/dev/null)"
hyprctl hyprpaper preload "$WP" >/dev/null 2>&1
if [ -n "$MON" ] && [ "$MON" != "null" ]; then
  hyprctl hyprpaper wallpaper "$MON,$WP" >/dev/null 2>&1
else
  hyprctl hyprpaper wallpaper ",$WP" >/dev/null 2>&1
fi
