#!/usr/bin/env bash
sel=$(printf "lock\nlogout\nreboot\nshutdown" | wofi --dmenu --prompt ":: power")
case "$sel" in
  lock) hyprlock ;;
  logout) hyprctl dispatch exit ;;
  reboot) systemctl reboot ;;
  shutdown) systemctl poweroff ;;
esac
