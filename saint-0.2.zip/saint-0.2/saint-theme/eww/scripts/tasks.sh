#!/usr/bin/env bash
# emit the task list as a JSON array; edit ~/.config/eww/tasks.txt (one per line)
f="$HOME/.config/eww/tasks.txt"
[ -f "$f" ] || printf 'Update threat intel\nAnalyze artifacts\nReview SIEM alerts\nLab: new scenario\nWrite report\n' > "$f"
jq -R . "$f" | jq -cs .
