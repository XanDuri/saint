#!/usr/bin/env bash
case "$1" in
  cpu)     top -bn1 | awk '/^%?Cpu|Cpu\(s\)/{for(i=1;i<=NF;i++) if($i ~ /id/){gsub(/[^0-9.]/,"",$(i-1)); printf "%.0f", 100-$(i-1); exit}}' ;;
  mem)     free | awk '/Mem:/{printf "%.0f", $3/$2*100}' ;;
  memtxt)  free -m | awk '/Mem:/{printf "%.1fG/%.0fG", $3/1024, $2/1024}' ;;
  gpu)     nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -dc '0-9' || echo 0 ;;
  disk)    df --output=pcent / | tail -1 | tr -dc '0-9' ;;
  disktxt) df -h --output=used,size / | tail -1 | awk '{print $1"/"$2}' ;;
esac
