#!/usr/bin/env bash
command -v playerctl >/dev/null || { [ "$1" = title ] && echo "no player"; exit 0; }
case "$1" in
  title)  playerctl metadata title 2>/dev/null || echo "nothing playing" ;;
  artist) playerctl metadata artist 2>/dev/null || echo "" ;;
  status) playerctl status 2>/dev/null || echo "Stopped" ;;
  pct)    pos=$(playerctl position 2>/dev/null); len=$(playerctl metadata mpris:length 2>/dev/null)
          awk -v p="${pos:-0}" -v l="${len:-0}" 'BEGIN{l=l/1000000; if(l>0) printf "%.0f", p/l*100; else print 0}' ;;
esac
