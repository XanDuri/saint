# SAINT — Plymouth boot splash

The SAINT logo crystallises out of a falling character matrix, in a dithered
4-colour fire palette, then holds (with a light glyph flicker) until boot finishes.
Includes a styled LUKS password prompt (`:: unlock SAINT`).

```
saint/
├── saint.plymouth     # theme descriptor
├── saint.script       # Plymouth script: plays intro once, then loops
├── intro-0..85.png    # 4.3 s intro  (1920x1080, 20 fps)
└── loop-0..39.png     # 2 s loop     (1920x1080, 20 fps)
```

Frames are loaded lazily (one at a time), so RAM use stays low. On screens that
aren't 1920x1080 the frames are scaled to fit, keeping the 16:9 aspect, centred.

---

## Install (Arch / SAINT)

### 1. Package + theme files

```bash
sudo pacman -S plymouth
sudo cp -r saint /usr/share/plymouth/themes/
```

### 2. Initramfs hooks — `/etc/mkinitcpio.conf`

Add `plymouth` **after `udev`** (or after `systemd`) and **before `encrypt`**
(or `sd-encrypt`) — otherwise the LUKS prompt won't show on the splash.

```
# busybox-based initramfs
HOOKS=(base udev plymouth autodetect microcode modconf keyboard keymap consolefont block encrypt filesystems fsck)

# or systemd-based initramfs
HOOKS=(base systemd plymouth autodetect microcode modconf keyboard sd-vconsole block sd-encrypt filesystems fsck)
```

**NVIDIA (RTX 5050)** — the splash needs early KMS:

```
MODULES=(nvidia nvidia_modeset nvidia_uvm nvidia_drm)
```

and **remove `kms`** from `HOOKS` (it pulls in `nouveau`, which conflicts with
`nvidia-open`).

### 3. Kernel parameters

Add `quiet splash nvidia_drm.modeset=1`.

- **systemd-boot:** append to the `options` line in `/boot/loader/entries/*.conf`
- **GRUB:** add to `GRUB_CMDLINE_LINUX_DEFAULT` in `/etc/default/grub`, then
  `sudo grub-mkconfig -o /boot/grub/grub.cfg`

If the splash still doesn't appear on NVIDIA, also add `nvidia_drm.fbdev=1`.

### 4. Activate (sets the theme and rebuilds the initramfs)

```bash
sudo plymouth-set-default-theme -R saint
```

Reboot.

---

## Test without rebooting

From a text console (Ctrl+Alt+F3), not from the desktop:

```bash
sudo plymouthd
sudo plymouth --show-splash
sleep 8
sudo plymouth ask-for-password --prompt="test"   # check the LUKS prompt, Esc/Enter to dismiss
sudo plymouth --quit
```

## Notes

- The boot log in the frames is decorative (it's baked into the animation);
  real kernel messages stay hidden behind `quiet splash`. Press **Esc** during
  boot to toggle the real log.
- To change the text, colours or timing, edit the HTML preview and re-render the
  frames; the script only needs `INTRO_N` / `LOOP_N` updated if frame counts change.
