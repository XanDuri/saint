# SAINT 0.1 — a defender's Arch

Unzip, then from inside the folder:

    cd saint-0.1
    bash install.sh

Run it as your **normal user** (not root) on a freshly installed Arch system.
It installs the NVIDIA open driver, a themed Hyprland desktop, the blue-team /
DFIR toolkit, clones your repos into ~/saint, and installs the SAINT boot splash.

Contents:
  install.sh        the installer (idempotent-ish; AUR failures don't stop it)
  saint-theme/      hypr · waybar · wofi · kitty · mako configs + wallpaper
  plymouth/saint/   the SAINT boot splash (auto-installed)

After it finishes, do the 3 manual steps it prints (kernel cmdline, Wazuh
server address, reboot). Full notes are in plymouth/saint/README.md.

Desktop: Hyprland + Waybar + eww dashboard (System / Music / Tasks cards),
         fastfetch, crimson theme, your red-leaves wallpaper.
         Edit tasks in ~/.config/eww/tasks.txt

Keybinds: SUPER+Q terminal · SUPER+R launcher · SUPER+C close · SUPER+L lock
          SUPER+SHIFT+S region screenshot
